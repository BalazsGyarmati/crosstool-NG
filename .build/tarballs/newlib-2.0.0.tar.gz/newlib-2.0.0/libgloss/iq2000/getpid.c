#include <_ansi.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "trap.h"


_getpid (n)
{
  return 1;
}
